tinyMCE.addI18n('en.helpmenu',{
	desc : 'helpmenu button'
});
