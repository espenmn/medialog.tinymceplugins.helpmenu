tinyMCE.addI18n('en.helpmenu_dlg',{
	title : 'Helpmenu'
});
