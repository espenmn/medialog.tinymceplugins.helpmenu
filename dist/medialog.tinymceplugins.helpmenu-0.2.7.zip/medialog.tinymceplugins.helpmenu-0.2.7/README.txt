Introduction
============

This is a plugin for `TinyMCE` editor for Plone.
http://plone.org/products/tinymce/

It is trying to add a "help menu to the tiny mce toolbar"

Changelog
=========

0.2.5
--------
* Translation is not working for Nynorsk, so default language is now norwegian


0.2.4
--------
* Added back a few more files that had not made it to github.


0.2.3
--------
* Added back doc folder that had disappeared.

0.2.2
--------

* Added a few parts in german 


0.2.1
--------

* Added a few parts in english (like a description of the buttons)


0.2
--------

* Added translations

0.1
--------

* Added images and gaid.htm


0.0.1
--------

* Initialversion